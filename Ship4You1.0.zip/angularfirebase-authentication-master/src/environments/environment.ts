// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyCEUyOmeQI4vucPgq8yKETxeT8TKElNRrg",
    authDomain: "ship4you-1573484667678.firebaseapp.com",
    databaseURL: "https://ship4you-1573484667678.firebaseio.com",
    projectId: "ship4you-1573484667678",
    storageBucket: "ship4you-1573484667678.appspot.com",
    messagingSenderId: "695447005907",
    appId: "1:695447005907:web:bde5bb52ca8757ae708226",
    measurementId: "G-Z0ZCM7TMHE"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
