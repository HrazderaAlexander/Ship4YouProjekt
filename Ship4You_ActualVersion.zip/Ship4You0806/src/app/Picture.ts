export class Picture{  
  static saveFilePath: string;
  static saveFileNameType: string;
  static saveDownloadUrl: string;
  static saveName: string;
  static saveBrand: string;
}