export interface BoatData{  
    vintage:number;
    name:string;
    type:string;
    location:string;
    lessor:string;
    cabins:string;
    length:string;
    sail:string;
    numberOfPeople:string;
    masts:string;
  }