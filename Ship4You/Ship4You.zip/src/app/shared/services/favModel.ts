export class FavModel {
    uid: string;
    boatId: string;
    fav: boolean;
 }