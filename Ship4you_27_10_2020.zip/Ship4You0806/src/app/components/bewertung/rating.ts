export class Rating{
    idRating:string;
    username:string;
    text:string;
    date:string;
    ratingStars:number;
}