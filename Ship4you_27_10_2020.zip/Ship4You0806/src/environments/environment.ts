// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyBFq38FNc1bjafRGUBJwNk-i1TmVNTFO24",
    authDomain: "ship4you-36b43.firebaseapp.com",
    databaseURL: "https://ship4you-36b43.firebaseio.com",
    projectId: "ship4you-36b43",
    storageBucket: "ship4you-36b43.appspot.com",
    messagingSenderId: "1041302765016",
    appId: "1:1041302765016:web:537f8da5de69f2649ac6ad",
    measurementId: "G-LVNLK5H9NL"
}
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
