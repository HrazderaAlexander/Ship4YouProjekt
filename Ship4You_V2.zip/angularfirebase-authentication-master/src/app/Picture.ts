export class Picture{  
  static saveFilePath: string;
  static saveFileNameType: string;
}