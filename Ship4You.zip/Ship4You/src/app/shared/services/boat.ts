export interface Boat { //Daten des Bootes
    id: string[];
    name: string;
    vermieter: string;
    schiffstyp: string;
 }