export interface pictureArrayInterface{
    picturePathString: string[];
}