export interface User { //Daten des Users
   uid: string;
   email: string;
   displayName: string;
   photoURL: string;
   emailVerified: boolean;
}