export interface FavModel {
    uid: string;
    boatId: string;
    fav: boolean;
 }